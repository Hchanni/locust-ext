
# Locust Extension Library

This library provides a custom Locust command line argument to send a GitHub dispatch event when a load test completes.

## Installation
